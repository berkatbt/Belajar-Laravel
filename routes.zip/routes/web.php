<?php

use Illuminate\Support\Facades\Route;
use PhpParser\Builder\Function_;

Route::get('/', function () {
    return view('welcome');
});


Route::get('/mahasiswa/fisilkom/anto', function () {
    echo '<h2 style="text-align: center"><u>halo semua</u></h1>';
    echo '<p>nama saya berkat</p>';
});

Route::get('/siswa/{namabarang}/{merek}', function ($namabarang, $merek) {
    return nl2br("tampilkan data barang yaitu: $namabarang\nmerek: {$merek}");
});

Route::get(
    '/data/{jenis}/{nama}',
    function ($a = 'iphone', $b = 'iphone 16 pro max') {
        return "cek sisa stok untuk $a, $b";
    }
);

Route::get('/user/{id}', function ($id) {
    return "Tampilkan user dengan id = $id";
})->where('id', '[A-z]{6}[0-9]+');

Route::get('/halo', function () {
    return 'halo semuanya';
});

Route::get('/hubungi-kami', function () {
    return '<i>hubungi kami</i>';
});

Route::redirect('/contact-us', '/hubungi-kami', 301);

// Route::fallback(function () {
//     return '<h1 style="text-align:center;"><i>404😝</i></h1>';
// });

// Route group
Route::prefix('/Admin')->group(function () {

    Route::get('/siswa', function () {
        echo "<p>daftar siswa</p>";
    });

    Route::get('/guru', function () {
        echo "<p>daftar guru</p>";
    });

    Route::get('/kariawan', function () {
        echo "<p>daftar kariawan</p>";
    });
});

//Route parameter
Route::get('/buku/{a}', function ($a) {
    return "buku ke $a";
});

Route::get('/buku/{b}', function ($b) {
    return "buku saya ke $b";
});

Route::get('/buku/{c}', function ($c) {
    return "buku kita ke $c";
});

// Route::get('mahasiswa', function () {
//     return view(
//         'universitas.mahasiswa',
//         [
//             "mahasiswa01" => "Jonatan vanlentino aditia",
//             "mahasiswa02" => "Rendy brandom yendedy",
//         ]
//     );
// });
Route::get('/mahasiswa', function () {
    $arrMahasiswa = [
        "Risa Lestari",
        "Rudi Hermawan",
        "Bambang Kusumo",
        "Lisa Permata"
    ];

    return view('universitas.mahasiswa', ['nama' => $arrMahasiswa]);
});


// Route::get('mahasiswa', function () {
//     return view('universitas.mahasiswa')->with('judulutama', 'belajar Route');
// });

// Route::get('/nama', function () {
//     return view('universitas.nama')->with('namaMahasiswa','Berkat' );
// });

Route::get('/test', function () {
    $nama= 'pratama iman berka batee';
    $nilai= 17; 
    return view('test', compact('nama','nilai'));   
});

Route::get('/datamahasiswa', function( ){
    $arrMahasiswa = [
        "Risa Lestari",
        "Rudi Hermawan",
        "Bambang Kusumo",
        "Lisa Permata"
    ];
    return view('universitas.datamahasiswa')-> with('mahasiswa', $arrMahasiswa);
});

Route::get('/gallery', function( ){
    return view('universitas.gallery');
});

Route::get('/dosen', function( ){
    $arrDosen = [
        "Dr. Risa Lestari, M.Kom",
        "Dr. Rudi Hermawan, M.Kom",
        "Dr. Bambang Kusumo, M.Kom",
        "Dr. Lisa Permata, M.Kom"
    ];
    return view('universitas.dosen')-> with('dosen', $arrDosen);
});
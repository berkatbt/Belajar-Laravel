<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\PageController;

Route::get('/coba', [PageController::class, 'cobaclass']);

Route::get('/', [PageController::class, 'index']);
Route::get('/mahasiswa', [PageController::class, 'tampil']);

Route::get('/selamat-datang', function () {
    return view('selamat-datang');
});

Route::get('/halo', function () {
    return view('halo');
});

Route::get('/test', function () {
    return view('test');
});

Route::get('/satu', [ColletionController::class, 'collectionSatu']);
Route::get('/dua', [ColletionController::class, 'collectionDua']);
Route::get('/tiga', [ColletionController::class, 'collectionTiga']);
Route::get('/empat', [ColletionController::class, 'collectionEmpat']);
Route::get('/lima', [ColletionController::class, 'collectionLima']);
Route::get('/enam', [ColletionController::class, 'collectionEnam']);
import './bootstrap';

//tampilkan alert ketika tombol diklik
 window.addEventListener('DOMContentLoaded', function() {
    alert('Selamat Datang di Halaman Universitas');
 }
);
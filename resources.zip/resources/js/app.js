import './bootstrap';
import * as bootstrap from 'bootstrap'
import './script1';
import './script2';
import '../css/app.css';

new bootstrap.Popover(document.getElementById('myPopover'))

window.addEventListener('DOMContentLoaded', () => {
    alert('selamat datang di website saya');
});
let h2Node = document.getElementsByTagName("h2")[0];

h2Node.addEventListener("mouseover", function(e) {
    e.target.style.textAlign = "right";
});
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/bootstrap.min.css">
    <title>Document</title>
</head>

<body>
    <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
        <div class="container">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="/dataMahasiswa">Data Mahasiswa</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/dosen">Daftar Dosen</a>
                </li>
                <li class="nav-item">
                    <a href="/gallery" , class="nav-link">gallery</a>
                </li>
            </ul>
        </div>

        <div class="container text-center mt-3 p-4 bg-white">
            <h1 class="mb-3">Gallery</h1>
            <div class="row">
                <div class="col-sm-8 col-md-6 m-auto">
                    <div>
                        <img class="rounded-circle img-thumbnail m-2" src="/img/Download.png" alt="Foto">
                        <img class="rounded-circle img-thumbnail m-2" src="/img/Download.png" alt="Foto">
                        <img class="rounded-circle img-thumbnail m-2" src="/img/Download.png" alt="Foto">
                        <img class="rounded-circle img-thumbnail m-2" src="https://static.promediateknologi.id/crop/0x0:0x0/0x0/webp/photo/p2/78/2025/04/15/10-Anime-Shonen-Terbaik-Sepanjang-Masa-Menurut-Fans-Jepang-Siapa-Nomor-1-1177896819.jpg" alt="Foto">
                    </div>
                </div>
            </div>

            <footer class="bg-dark py-4 text-white mp-4">
                <div class="container">
                    Sistem Informasi Mahasiswa | Copyright © {{ date('Y') }} Duniaikom
            </footer>

        </div>
    </nav>
</body>

</html>
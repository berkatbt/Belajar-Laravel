<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/dose.min.css">
    <title>Document</title>
</head>

<body>
    <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
        <div class="container">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="/datamahasiswa">Data Mahasiswa</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/dosen">Daftar Dosen</a>
                </li>
                <li class="nav-item">
                    <a href="/gallery" , class="nav-link">gallery</a>
                </li>
            </ul>
        </div>

            <div class="container text-center mt-3 p-4 bg-white">
                <h1 class="mb-3">data dosen</h1>
                <div class="col-sm-8 col-md-6 m-auto">
                    <ol class="list-group">
                        @forelse ($dosen as $val)
                            <li class="list-group">{{ $val }}</li>
                        @empty
                            <div class="alert alert-dark d-inline-block">tidak ada data...</div>
                        @endforelse
                    </ol>
                </div>
            </div>
            <footer class="bg-dark py-4 text-white mp-4">
                <div class="container">
                    Sistem Informasi Mahasiswa | Copyright © {{ date('Y') }} Duniaikom
            </footer>
    </nav>
</body>

</html>
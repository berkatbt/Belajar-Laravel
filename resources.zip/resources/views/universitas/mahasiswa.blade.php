<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Daftar Mahasiswa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container text-center mt-4">
        <h1>Daftar Mahasiswa</h1>
        <ol class="list-group my-4">
            <?php
            foreach ($nama as $siswa) {
                echo "<li class=\"list-group-item\">$siswa</li>";
            }
            ?>
        </ol>
        <div>
            <img class="rounded-circle img-thumbnail m-2" src="/img/Download.png" alt="Foto">
            <img class="rounded-circle img-thumbnail m-2" src="/img/Download.png" alt="Foto">
            <img class="rounded-circle img-thumbnail m-2" src="/img/Download.png" alt="Foto">
            <img class="rounded-circle img-thumbnail m-2" src="/img/Download.png" alt="Foto">
        </div>
        <div class="mt-3">
            Copyright © <?php echo date("Y");?> Duniaikom
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

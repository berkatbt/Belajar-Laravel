<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div>
        <h1>data siswa</h1>
        <div>
            <ol>
                @forelse ($mahasiswa as $val)
                <li>{{ $val }}</li>
                @empty
                <div>tidak ada data....</div>
                @endforelse
            </ol>
        </div>
    </div>
</body>
</html>